export class Message {
    public user: string = '';
    public msgText: string = '';
  }